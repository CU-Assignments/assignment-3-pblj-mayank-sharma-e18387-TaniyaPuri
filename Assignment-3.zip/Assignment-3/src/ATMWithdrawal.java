import java.util.Scanner;

public class ATMWithdrawal {
    private static final int CORRECT_PIN = 1234;
    private static double balance = 3000;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            System.out.print("Enter PIN: ");
            int pin = sc.nextInt();
            if (pin != CORRECT_PIN) {
                throw new IllegalArgumentException("Invalid PIN.");
            }

            System.out.print("Withdraw Amount: ");
            double amount = sc.nextDouble();
            if (amount > balance) {
                throw new IllegalStateException("Insufficient balance.");
            }

            balance -= amount;
            System.out.println("Withdrawal successful. Remaining balance: " + balance);
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage() + " Current Balance: " + balance);
        }
    }
}

