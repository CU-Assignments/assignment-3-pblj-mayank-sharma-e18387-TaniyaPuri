import java.util.Scanner;

class CourseFullException extends Exception {
    public CourseFullException(String message) {
        super(message);
    }
}

class PrerequisiteNotMetException extends Exception {
    public PrerequisiteNotMetException(String message) {
        super(message);
    }
}

public class UniversityEnrollmentSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            String course = "Advanced Java";
            String prerequisite = "Core Java";
            boolean prerequisiteCompleted = false; // Assume prerequisite is not completed.

            System.out.print("Enroll in Course: " + course + "\nPrerequisite: " + prerequisite + "\nStatus: ");
            if (!prerequisiteCompleted) {
                throw new PrerequisiteNotMetException("Complete " + prerequisite + " before enrolling in " + course + ".");
            }

            System.out.println("Enrollment successful in " + course);
        } catch (PrerequisiteNotMetException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}

